<?php
// cr�er des constantes pour mes param�tres

define("SERVEUR","localhost");
define("ADMIN", "root");
define("PASSWORD","");
define("DATABASE","cavadbmain");




?>